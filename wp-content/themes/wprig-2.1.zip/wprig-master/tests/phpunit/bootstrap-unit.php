<?php
/**
 * WP Rig unit tests bootstrap script.
 *
 * @package wp_rig
 */

// Run common tests script.
require __DIR__ . '/bootstrap-common.php';
