<?php
 /**
 * Kult Of Pop Theme.
 *
 *
 * @package Kult Of Pop
 * @author  Travis E Mikolay
 * @copyright Copyright (c) 2019, Travis E Mikolay
 * @license GPL-2.0-or-later
 * @link    https://www.KultOfPop.com/
 */

/**
 * Elements to output as html5.
 */
return array(
	'caption',
	'comment-form',
	'comment-list',
	'gallery',
	'search-form',
);
