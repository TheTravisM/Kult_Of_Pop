<?php
/**
 * Template part for displaying the header navigation menu
 *
 * @package kult_of_pop
 */

namespace WP_Rig\WP_Rig;

/* // todo: Create the SCSS for the footer  */
kult_of_pop()->print_styles( 'kult-of-pop-c-footer-fine-print' );

?>

<!-- [ Footer Fine Print ] -->
<div class="c-footer_fine-print">
	<p>COPYRIGHT 2019 . ALL RIGHTS RESERVED.<p>
</div>
