<?php
/**
 * Template part for displaying the page head
 *
 * @package kult_of_pop
 */

namespace WP_Rig\WP_Rig;

?>

<!-- [ KULT Prefetch ] -->

<!-- Google Font -->
<link rel="dns-prefetch preconnect" href="//fonts.googleapis.com"  crossorigin>
<link rel="dns-prefetch preconnect" href="//fonts.gstatic.com" crossorigin>
<!-- CDN Cloud Flair -->
<link rel="dns-prefetch preconnect" href="//cdnjs.cloudflare.com" crossorigin>
<!-- Google CDN -->
<link rel="dns-prefetch preconnect"" href="//ajax.googleapis.com" crossorigin>
