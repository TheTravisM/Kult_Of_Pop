<?php
/**
 * Template part for displaying related posts
 *
 * @package kult_of_pop
 */

namespace WP_Rig\WP_Rig;

?>

<h2> related post
<!--  kult_of_pop()->display_related_posts(); -->
</h2>
