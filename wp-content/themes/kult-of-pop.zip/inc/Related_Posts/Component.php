<?php
/**
 * WP_Rig\WP_Rig\Related_Posts\Component class
 *
 * @package kult_of_pop
 */

namespace WP_Rig\WP_Rig\Related_Posts;

use WP_Rig\WP_Rig\Component_Interface;
use WP_Rig\WP_Rig\Templating_Component_Interface;


/**
 * Class for related posts.
 *
 * Exposes template tags:
 * * `kult_of_pop()->the_comments( array $args = [] )`
 *
 * @link https://wordpress.org/plugins/amp/
 */
class Component implements Component_Interface, Templating_Component_Interface {

	/**
	 * Gets the unique identifier for the theme component.
	 *
	 * @return string Component slug.
	 */
	public function get_slug() : string {
		return 'related_posts';
	}

	/**
	 * Adds the action and filter hooks to integrate with WordPress.
	 */
	public function initialize() {
		add_action();
	}

	/**
	 * Gets template tags to expose as methods on the Template_Tags class instance, accessible through `kult_of_pop()`.
	 *
	 * @return array Associative array of $method_name => $callback_info pairs. Each $callback_info must either be
	 *               a callable or an array with key 'callable'. This approach is used to reserve the possibility of
	 *               adding support for further arguments in the future.
	 */
	public function template_tags() : array {
		return [
			'display_related_posts' => [ $this, 'display_related_posts' ],
		];
	}

	/**
	 * Display the realated posts
	 */
	public function display_related_posts() {
		echo '<h2>Related Posts!</h2>';
	}
}
